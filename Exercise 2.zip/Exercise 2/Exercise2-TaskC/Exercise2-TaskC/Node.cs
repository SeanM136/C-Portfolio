﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_TaskC
{
    class Node<T> where T : IComparable
    {
        private T data;
        public Node<T> Left, Right;//Create two nodes of type T
        private int count = 1;//Count of each node

        private int balanceFactor = 0;//How many items on each side of tree

        public Node(T item)//Function that takes in an item and creates two nodes
        {
            data = item;
            Left = null;
            Right = null;
            count = 1;
        }
        public T Data
        {
            set { data = value; }
            get { return data; }
        }

        public int BalanceFactor//Allows changes and retrieval of amount
        {
            get { return balanceFactor; }
            set { balanceFactor = value; }
        }
        public int Count //Allows changes and retrieval of amount
        {
            set { count = value; }
            get { return count; }
        }

    }
}
