﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_TaskC
{
    class BSTree<T> : BinTree<T> where T : IComparable
    {  
        public BSTree()//Declare a BSTree with no root node in tree since root = null
        {
            root = null;
        }

        public void InsertItem(T item)//Inserting items into tree
        {
            insertItem(item, ref root);
        }

        private void insertItem(T item, ref Node<T> tree)
        {
            if (tree == null)
                tree = new Node<T>(item);//Create new node


            else if (item.CompareTo(tree.Data) < 0)//If item is less than 0 then insert item
                insertItem(item, ref tree.Left);

            else if (item.CompareTo(tree.Data) > 0)//If item is more than 0 than insert item
                insertItem(item, ref tree.Right);
     
        }

        public int Height()//Calculate height of the tree
        {
            int h = Height(root);
            return h;
        }

        protected int Height(Node<T> tree)
        {
            if (tree == null)//If no nodes than 0 is the result
                return 0;
            else
                return 1 + Math.Max(Height(tree.Left), Height(tree.Right)); //Calculates height of each node if tree is not null

        }

        public int Count()//Counts number of nodes in tree
        {
            int c = Count(root);
            return c;
        }

        private int Count(Node<T> tree)//Counts the number of nodes in tree if tree is not null
        {
            {
            if (tree == null)
                return 0;
            else
                return 1 + Math.Max(Count(tree.Left), Count(tree.Right));
        }



    }
}
