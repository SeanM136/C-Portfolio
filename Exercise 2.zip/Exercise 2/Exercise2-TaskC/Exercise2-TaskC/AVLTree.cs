﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_TaskC
{
    class AVLTree<T> : BSTree<T> where T : IComparable
    {
        public new void InsertItem(T item)//Method declared which takes one parameter
        {
            insertItem(item, ref root);
        }

        private void insertItem(T item, ref Node<T> tree)//Insert items into tree
        {

            if (tree == null)
                tree = new Node<T>(item);//Create new node 
            else if (item.CompareTo(tree.Data) < 0)
                insertItem(item, ref tree.Left);//Insert item left of node
            else if (item.CompareTo(tree.Data) > 0)
                insertItem(item, ref tree.Right);//Insert item right of node
            else if (item.CompareTo(tree.Data) == 0) // if item is already in tree, increase amount by 1
            {
                tree.Count++;
            }

            tree.BalanceFactor = Height(tree.Left) - Height(tree.Right);//Create tree object - balance factor is calculated here

            if (tree.BalanceFactor <= -2)//Code will rotate tree left or right it if its not balanced
                rotateLeft(ref tree);
            if (tree.BalanceFactor >= 2)
                rotateRight(ref tree);

        }

        private void rotateLeft(ref Node<T> tree)//Rotates tree left
        {
            if (tree.Right.BalanceFactor > 0)  //double rotates the tree
                rotateRight(ref tree.Right);


            Node<T> oldroot = tree;
            Node<T> newroot = oldroot.Right;//Create a new root node from the old root node's right child node

            oldroot.Right = newroot.Left;

            newroot.Left = oldroot;

            tree = newroot;
            //Creates a new root node from old root and then child nodes - left and right are swapped
        }

        private void rotateRight(ref Node<T> tree)//Rotate tree right
        {
            if (tree.Right.BalanceFactor < 0)  //double rotates the tree
                rotateRight(ref tree.Right);

            Node<T> oldroot = tree;
            Node<T> newroot = oldroot.Left;

            oldroot.Left = newroot.Right;

            newroot.Right = oldroot;

            tree = newroot;
            //Old root's left node becomes new root's right node
        }
            public string Contains(T item)//Used to determine if an item is present in the tree 
             {
                 String i = Contains(root, item);//Assign result of contain method to i
                 return i;

             }

             private string Contains(Node<T> tree, T item)//Takes in item and returns true if item is found
             {
                 if (tree == null)//Checks to see if tree node is null
                 {
                     return "Item not found";
                 }

                 else//Compares item with data in tree to see if it exists
                 {
                     if (item.CompareTo(tree.Data) == 0)//Checks if item is equal to root node
                     {
                         return "Item is found. Count: " + tree.Count;//Displays how many of same item was found
                     }
                     else if (item.CompareTo(tree.Data) > 0)//Checks Right if more than 0
                     {
                         return Contains(tree.Right, item);//Checks if item is contained in left or right side
                     }
                     else if (item.CompareTo(tree.Data) < 0)//Checks left is less than 0
                     {
                         return Contains(tree.Left, item);
                     }

                     return "Error";
                 }



             }

     
    }
}
