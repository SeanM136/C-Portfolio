﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_TaskC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AVLTree<string> avltree = new AVLTree<string>();//Create new AVL Tree
            string user = "";
            string buffer = "";

            while(true)
            {
                Console.WriteLine("Type one of the following - Insert, Present");//Displayed to user
                user= Console.ReadLine();
                buffer = "";
                if(user == "Insert")
                {
                    Console.WriteLine("Insert a word into the AVL Tree");
                    user= Console.ReadLine();
                    avltree.InsertItem(user);//Call InsertItem method based on user input
                }
                else if (user == "Present")
                {
                    Console.WriteLine("Enter a word to see if it is present within the tree");
                    user= Console.ReadLine();
                    Console.WriteLine(avltree.Contains(user));//Call Contains method based on user input
                }
               
            }
        }
    }
}
