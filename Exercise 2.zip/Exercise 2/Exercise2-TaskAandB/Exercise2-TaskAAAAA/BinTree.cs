﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_TaskAAAAA
{
    class BinTree<T> where T : IComparable
    {
        protected Node<T> root;
        public BinTree()  //creates an empty tree
        {
            root = null;
        }
        public BinTree(Node<T> node)  //creates a tree with node as the root
        {
            root = node;
        }
        public void InOrder(ref string buffer)//Function
        {
            inOrder(root, ref buffer);
        }

        private void inOrder(Node<T> tree, ref string buffer)//Put nodes in order traversal
        {
            if (tree != null)//Iterates through tree and prints out each node's data
            {
                inOrder(tree.Left, ref buffer);//Left Node printed
                buffer += tree.Data.ToString() + ",";
                inOrder(tree.Right, ref buffer);//Right Node printed
            }
        }

        public void PreOrder(ref string buffer)//Function takes in two parameters
        {
            PreOrder(root, ref buffer);
        }

        private void PreOrder(Node<T> tree, ref string buffer)//Puts nodes in pre-order traversal
        {
            if (tree != null)//Checks if tree is null
            {
                buffer += tree.Data.ToString() + ",";
                InOrder(tree.Left, ref buffer);//Left Node printed
                InOrder(tree.Right, ref buffer);//Right Node printed
            }
        }

        public void PostOrder(ref string buffer)//Function takes in two parameters
        {
            PostOrder(root, ref buffer);
        }

        private void PostOrder(Node<T> tree, ref string buffer)//Puts nodes in post-order traversal
        {
            if (tree != null)//Checks to see if treee is null -meaning not been created yet
            {
                inOrder(tree.Left, ref buffer);//Left Node printed
                inOrder(tree.Right, ref buffer);//Right Node printed
                buffer += tree.Data.ToString() + ",";
            }
        }

    }
}
