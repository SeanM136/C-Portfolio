﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Exercise2_TaskAAAAA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BSTree<string> tree = new BSTree<string>();//New tree created called 'tree'
            string user = "";
            string buffer = "";

            while (true)//Code will keep running until user exits loop
            {
                Console.WriteLine("Type one of the following - Insert, Height, In-Order, Post-Order, Pre-Order, Count, Contain, Exit");
                user = Console.ReadLine();
                buffer = "";
                if (user == "Insert")
                {
                    Console.WriteLine("Insert a word into the tree: ");
                    user = Console.ReadLine();//Read input from console
                    tree.InsertItem(user);//Call InsertItem method and display output based on user input
                }
                else if (user == "Height")
                {
                    Console.WriteLine("Height of the tree: " + tree.Height());//Call height method
                }
                else if (user == "In-Order")
                {
                    tree.InOrder(ref buffer);//Call InOrder method using user's input
                    Console.WriteLine("In Order: " + buffer);
                }
                else if (user == "Post-Order")
                {
                    tree.PostOrder(ref buffer);//Call PostOrder method using user's input
                    Console.WriteLine("Post Order: " + buffer);
                }
                else if (user== "Pre-Order")
                {
                    tree.PreOrder(ref buffer);//Call PreOrder method using user's input
                    Console.WriteLine("Pre-Order: " + buffer);
                }
                else if (user == "Count")
                {
                    Console.WriteLine("Count: " + tree.Count());//Call Count method
                }
                else if (user == "Contain")
                {
                    Console.WriteLine("Enter a word from the tree: ");
                    user = Console.ReadLine();
                    Console.WriteLine(tree.Contains(user));//Call Contains method using user's input
                }
                else if (user == "Exit")
                {
                    Environment.Exit(0);
                }
            }

        }
    }
}
