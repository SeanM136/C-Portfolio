﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2_TaskAAAAA
{
    class Node<T> where T : IComparable
    {
        private T data;
        public Node<T> Left, Right;//Create two nodes of type T 

        public Node(T item)//Function that takes in an item and creates two nodes
        {
            data = item;
            Left = null;
            Right = null;
        }
        public T Data
        {
            set { data = value; }
            get { return data; }
        }
    }
}
