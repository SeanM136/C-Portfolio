﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3___Task_B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] ages = new int[5];//Create a array of 5 integers
            ages[0] = 11;
            ages[1] = 16;
            ages[2] = 13;
            ages[3] = 12;
            ages[4] = 15;

            SelectionSortGeneric<int>(ages);//Calls Selection Sort method and sorts age array
            for ( int i = 0; i < ages.Length; i++ )//Iterate through array and print out each value
            {
                Console.WriteLine(ages[i] );
            }
           

            string[] names = { "Sean", "Tom", "John", "Bob", "Chris" };
            Student[] people = new Student[5];//Creates an array of 5 student objects
            //Create list of students
            for(int i = 0; i < people.Length; i++ )//Loops through names and creates object for each one
            {
                people[i] = new Student(names[i], ages[i]);//Iterate through list and assign each student name to name and age
            }

            SelectionSortGeneric<Student>(people);//Calls Selection Sort method and sorts array of students

            for (int i = 0; i < people.Length; i++)//Loop through student objects and print out names
            {
                Console.Write(people[i].ToString() + ", ");
            }
            Console.ReadKey();
        }

        static public void SelectionSortGeneric<T>(T[] A) where T : IComparable
        {
            for (int i = 0; i < A.Length; i++)//Sorts array in ascending order
            {
                int smallest = i;
                for (int j = i + 1; j < A.Length; j++)//Finds the smallest element in array
                {
                    if (A[j].CompareTo(A[smallest]) < 0)//Compares each element in A with the next element until it finds one smaller than itself
                        smallest = j;
                }
                flip(ref A[i], ref A[smallest]);//Swap values between two different indexes so they can be sorted properly
            }
        }

        static void flip<T>(ref T a, ref T b) where T : IComparable//Flips values of a and b
        {
            T temp = a;
            a = b;
            b = temp;
        }
    }
}
