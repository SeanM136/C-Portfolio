﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3___Task_B
{
    internal class Student : IComparable//Allows it to be compared using CompareTo Method
    {
        private string name;//Cannot be accessed from other classes without permissions
        private int age;

        public Student(string Name, int Age)//Takes in two parameters - name and age
        {
            this.name = Name;
            this.age = Age;
        }

        public int Age
        {
            get { return this.age; }//Return value of variable 
            set { this.age = value; }//Assign value to variable
        }

        public string Name
        {
            get { return this.name; }//Return value of variable 
            set { this.name = value; }//Assign value to variable
        }

        public int CompareTo(Object obj)
        {
            Student other = (Student)obj;
            return Age.CompareTo(other.Age);//Compares two student ages and display names
        }

        public string ToString()//Returns a string with name and age
        {
            return this.name + " " + this.age;
        }
    }
}
