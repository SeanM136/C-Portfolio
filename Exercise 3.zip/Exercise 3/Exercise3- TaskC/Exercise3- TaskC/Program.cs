﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3__TaskC
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Request[] request = new Request[6];//Create an array of 6 requests
            int[] id = { 1, 2, 3, 4, 5, 6 };
            double[] start = { 12.00, 12.30, 16.30, 13.40, 12.10, 12.05 };
            double[] end = { 13.45, 12.45, 16.45, 15.35, 14.30, 15.10 };

            for (int i = 0; i < request.Length; i++)//Iterates through list of requests and displays them
            {
                request[i] = new Request(id[i], start[i], end[i]);//Request is made up of ID,Start and End
            }//Create a Request object for each element in array and assign it to a request object


            RequestSelection(request);
            
            Console.ReadLine();

        }
        static void quickSortDD2(Request[] items, int left, int right)//Sort array using quick sort method
        {//Sort array of Request objects
            int i, j;
            i = left; j = right;//Declare variables left and right
            Request pivot = items[left];

            while (i <= j)//Iterate over each item in array until it finds one that has a lower or equal value to pivot
            {
                for (; (items[i].CompareTo(pivot) < 0) && (i < right); i++) ;
                for (; (pivot.CompareTo( items[j]) < 0) && (j > left); j--) ;

                if (i <= j)
                    swap(ref items[i++], ref items[j--]);//Swap if elements are unequal
            }//After swapping two items. if any remaining either side then swap

            if (left < j) quickSortDD2(items, left, j);//Sorted if left < j
            if (i < right) quickSortDD2(items, i, right);//Sorted if i > right
        }


        static void swap(ref Request x, ref Request y)//Swaps the values of variables x and y
        {
            Request temp = x;
            x = y;
            y = temp;
        }

        static void RequestSelection(Request[] array)//Sorts array of requests 
        {
            
            quickSortDD2(array, 0, array.Length - 1);//Sort array of requests by finishing times in descending order

            double[] start = new double[array.Length];//Store start time
            for (int i = 0; i < start.Length; i++)
            {
                start[i] = array[i].Start;//Create array of start times
            }

            double[] end = new double[array.Length];//Store end time
            for (int i = 0; i < end.Length; i++)
            {
                end[i] = array[i].End;//Create array of end times
            }

            List<string> sel_act = new List<string>();//Create list of strings
            int k = 0; //Used to keep track how many times it has iterated through array
            sel_act.Add(array[0].Display());
            for(int i =1; i < array.Length; i++)
            {//Does this until finds element that is greater than end time or when reaches end of array
                if(start[i] >= end[k])//Iterate through array and adds Display to sel_Act
                {
                    sel_act.Add(array[i].Display());
                    k = i;
                }
            }

            for (int i = 0; i < sel_act.Count; i++)
            {
                Console.WriteLine(sel_act[i]);//Print array in order starting with 0 and ending with length of list
            }
        }

    }
}
