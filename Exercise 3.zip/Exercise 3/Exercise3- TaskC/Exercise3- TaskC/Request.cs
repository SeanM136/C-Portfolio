﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3__TaskC
{
    internal class Request
    {
        private double start;//Start of request
        private double end;//End of request
        private int iD;//ID number of request

        public Request(int ID, double start, double end)//Constructor takes in 3 parameters
        {
            this.start = start;
            this.end = end;
            this.iD = ID;
        }

        public int ID//Store value of ID
        {
            get { return iD; }
            set { iD = value; }
        }
        public double Start//Store value of Start
        {
            get { return start; }
            set { start = value; }
        }

        public double End//Store value of end
        {
            get { return end; }
            set { end = value; }
        }

        public int CompareTo(Object obj)//Compares Requests by checking end times
        {
            Request other = obj as Request;
            return End.CompareTo(other.End);//Compares end value to other end values
        }

        public string Display()//Display ID followed by start and end times
        {
            return this.ID + " " +  this.start + " " +  this.end;
        }
    }
}
