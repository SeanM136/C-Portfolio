﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_4__Task_B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Graph<string> graph = new Graph<string>();//Create a new graph 
            string user = "";

            while (true)//Loop used to iterate code
            {
                List<string> visited = new List<string>();
                Console.WriteLine("Type one of the following- Airport, Flight, Display, Display2(Connected/Direct Flights)");//Ask user for input
                user = Console.ReadLine();
                if (user == "Airport")
                {
                    Console.WriteLine("Please insert an airport: ");
                    user = Console.ReadLine();
                    graph.AddNode(user);//Call AddNode method based on user input
                }
                else if (user == "Flight")
                {
                    Console.WriteLine("Please insert an airport: ");
                    string a = Console.ReadLine();
                    Console.WriteLine("Please insert another airport: ");
                    string b = Console.ReadLine();
                    graph.AddEdge(a, b);//Call AddEdge method based on user input
                }
                else if (user == "Display")
                {
                    Console.WriteLine("Input a starting airport: ");
                    user= Console.ReadLine();
                    Console.WriteLine(graph.IsAdjacent(graph.GetNodeByID(user)));//Display direct flights from starting airport
                }
                else if (user == "Display2")
                {
                    Console.WriteLine("Input a starting airport: ");
                    user = Console.ReadLine();
                    graph.BreadthFirstTraverse(user, ref visited);//Display direct or connecting flights from starting airport
                    foreach (object o in visited)
                    {
                        Console.WriteLine(o);
                    }
                }
            }
        }
    }
}
