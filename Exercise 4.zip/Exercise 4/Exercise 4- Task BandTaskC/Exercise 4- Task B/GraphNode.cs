﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_4__Task_B
{
    public class GraphNode<T>//Represents node in graph
    {
        private T id; 
        private LinkedList<T> adjList;

        // constructor
        public GraphNode(T id)//Take ID a parameter - creating node with an ID
        {
            this.id = id;
            adjList = new LinkedList<T>();//Create a Linked List and assign to adjList
        }

        public T ID//Return value of stored ID - assigned to it's own variable
        {
            set { id = value; }
            get { return id; }
        }

        public void AddEdge(GraphNode<T> to)//Create edge
        {
            adjList.AddLast(to.ID);//Adds another node as adjacent node to this one
        }

        public LinkedList<T> GetAdjList()
        {
            return adjList;//Returns adjacent list
        }

    }
}
