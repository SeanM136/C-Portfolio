﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_4__Task_B
{
    public class Graph<T> where T : IComparable
    {

        
        private LinkedList<GraphNode<T>> nodes;//Store linked list of nodes
        private int counteredges = 0;//Count number of edges


        public Graph()
        {
            nodes = new LinkedList<GraphNode<T>>();//Create a list of empty nodes
        }



       
        public bool IsEmptyGraph()//Returns true if graph is empty - no nodes in graph
        {
            return nodes.Count == 0;
        }

       
        public void AddNode(T id)//Adds node to end of the list of nodes
        {

            nodes.AddLast(new GraphNode<T>(id));
        }

       
        public bool ContainsGraph(GraphNode<T> node)//Used to determine if a given node exists
        {

           

            foreach (GraphNode<T> n in nodes)//Iterates through nodes in graph
            {
                if (n.ID.CompareTo(node.ID) == 0)
                {

                    return true;//Returns true if ID equals given ID
                }

            }

            return false;//Otherwise return false
        }

       

        public GraphNode<T> GetNodeByID(T id)//Method used to return node with given ID
        {
            foreach (GraphNode<T> n in nodes)//Iterate over nodes in graph
            {
                if (id.CompareTo(n.ID) == 0) return n;//Return node if ID equals given ID
            }
            return null;//Otherwise return null
        }

        
        public void AddEdge(T from, T to)
        {
            GraphNode<T> n1 = GetNodeByID(from);//Retreives given node by ID and assigns it to 'n1'
            GraphNode<T> n2 = GetNodeByID(to);//Retrieves given node by ID and assigns it to 'n2'


            if (n1 != null & n2 != null)//If both nodes exist then add together to create one edge
            {
                n1.AddEdge(n2);
                counteredges++;//Counter of edge goes up by 1 everytime statement is iterated
            }
            else
                Console.WriteLine("Node/s not found in the graph. Cannot add the edge");
                //Display if no nodes are found in graph
        }


        public bool IsAdjacent(GraphNode<T> from, GraphNode<T> to)//Return true or false depending if a node is adjacent to another node 
        {

            foreach (GraphNode<T> n in nodes)//Iterate through nodes in graph
            {
                if (n.ID.CompareTo(from.ID) == 0)
                    if (from.GetAdjList().Contains(to.ID))//Compares from node with to node to see if adjacent
                        return true;

            }

            return false;
        }

        
        public int NumNodesGraph()//Returns the number of nodes in graph
        {
            return nodes.Count;
        }

        
        public int NumEdgesGraph()//Returns number of edges in graph
        {
            return counteredges;
        }

        public string IsAdjacent(GraphNode<T> start)//Checks if adjacent to 'start' node
        {

            foreach (GraphNode<T> n in nodes)//Iterates through all nodes in graph
            {

                if (n.ID.CompareTo(start.ID) == 0)//Checks if node is adjacent to 'start' node 
                {
                    LinkedList<T> next = start.GetAdjList();//If node is adjacent to start, return ID
                    return next.First().ToString();//If so then return next node's name in order to continue traversing through list
                }
            }
            return "No flights";//If not found then display
        }

        public void BreadthFirstTraverse(T startID, ref List<T> visited)//Traverses tree using breadth-first search algorithm

        {
            LinkedList<T> adj;//Create linkedlist
            Queue<T> toVisit = new Queue<T>();//Create queue

            toVisit.Enqueue(startID);//Adds 'startID' as element of queue

            T currentID;

            while (toVisit.Count != 0)
            {
               
                currentID = toVisit.Dequeue();//Retrieves current node ID from toVisit queue using dequeue
                visited.Add(currentID);//Store current node ID in 'visited'
                adj = GetNodeByID(currentID).GetAdjList();//Retrieve adjacent list of current node
                foreach (T n in adj)//Add all nodes in adjacency list of current node to queue
                {
                    if (!toVisit.Contains(n) && !visited.Contains(n))//If node is not already in 'toVisit' and 'visited'
                    {
                        toVisit.Enqueue(n);//Add each node in adjacent list of current node to queue 'toVisit'
                    }
                }
                //  (only if n is not in “visited” and not in “toVisit”)
            }
        }

    }
}
