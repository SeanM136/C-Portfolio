﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4_TaskA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Graph<string> graph = new Graph<string>();//Create a new graph 
            string user = "";

            while (true)//Loop used to iterate code
            {
                Console.WriteLine("Type one of the following- Node, Edge, Display");//Ask user for input
                user = Console.ReadLine();
                if (user == "Node")
                {
                    Console.WriteLine("Please insert a node: ");
                    user = Console.ReadLine();
                    graph.AddNode(user);//Call AddNode method based on user input
                }
                else if (user == "Edge")
                {
                    Console.WriteLine("Please insert one node: ");
                    string a = Console.ReadLine();
                    Console.WriteLine("Please insert another node: ");
                    string b = Console.ReadLine();
                    graph.AddEdge(a, b);//Call AddEdge method based on user input
                }
                else if (user == "Display")
                {
                    Console.WriteLine("Number of nodes: " + graph.NumNodesGraph());//Display number of nodes
                    Console.WriteLine("Number of edges: " + graph.NumEdgesGraph());//Display numebr of edges
                }
            }
        }
    }
}
