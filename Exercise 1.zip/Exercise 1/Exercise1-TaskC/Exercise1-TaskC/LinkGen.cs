﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1_TaskC
{
    class LinkGen<T>
    {
        private T data;
        private LinkGen<T> next;

        public LinkGen(T item)//Constructor takes an item
        {
            data = item;
            next = null;
        }
        public LinkGen(T item, LinkGen<T> list)//Constructor takes a list of items
        {
            data = item;
            next = list;
        }
        public LinkGen<T> Next//Used to get or set what's next in line for LinkGen object
        {
            set { this.next = value; }
            get { return this.next; }
        }

        public T Data//Sets the property to whatever is passed onto it
        {
            set { this.data = value; }
            get { return this.data; }
        }
    }
}
