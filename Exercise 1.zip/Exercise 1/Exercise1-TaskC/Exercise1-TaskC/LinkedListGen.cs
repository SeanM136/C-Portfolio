﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1_TaskC
{
    class LinkListGen<T> where T : IComparable
    {
        private LinkGen<T> list;// Declares a list from LinkGen class

        public LinkListGen()
        {

        }

        public void AppendItem(T item)//Takes in an item and adds it to end of list
        {
            LinkGen<T> temp = list;

            if (temp == null) 
            {
                list = new LinkGen<T>(item);//If value is null - create a new LinkGen 
            }
            else
            {
                while (temp.Next != null) //Iterate through list until element that has Next set is null
                {
                    temp = temp.Next;
                }

                temp.Next = new LinkGen<T>(item); //Replace element with new item
            }
        }
        public string DisplayList()//Displays list to user
        {
            LinkGen<T> temp = list;
            string buffer = "";
            while (temp != null)
            {
                buffer = buffer + temp.Data.ToString();
                temp = temp.Next;
            }
            return buffer;
        }
        public int NumberOfItems()//Return number of items in list
        {
            LinkGen<T> temp = list;
            int count = 0;
            while (temp != null) // move one link and add 1 to count
            {
                count++;
                temp = temp.Next;
            }
            return count;
        }
        public bool IsPresentItem(T item)//Checks to see if an item is present in list
        {
            LinkGen<T> temp = list;//LinkGen object
            while (temp != null)
            {
                if (item.CompareTo(temp.Data) == 0)
                    return true;
                temp = temp.Next;
            }
            return false;
        }
     
        public LinkGen<T> List
        {
            get { return list; }
        }
       
    }
}
