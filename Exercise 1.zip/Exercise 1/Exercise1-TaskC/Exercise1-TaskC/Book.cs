﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1_TaskC
{
    class Book : IComparable
    {
        private string title;//variables
        private string author;
        private string iSBN;

        public Book()//constructor
        {
            
        }
        public Book(string Title, string Author, string iSBN)//Create book object with three properties
        {
            this.title = Title;
            this.author = Author;
            this.iSBN = iSBN;//null values
        }

        public string Title//Public fields
        {
            get { return title; }
            set { title = value; }
        }

        public string Author//Public fields
        {
            get { return author; }
            set { author = value; }
        }

        public string ISBN//Public fields
        {
            get { return iSBN; }
            set { iSBN = value; }
        }

        public int CompareTo(Object obj) // compare ISBN to other ISBN
        {
            Book other = (Book)obj;
            return ISBN.CompareTo(other.ISBN);
        }
       
    }
}
