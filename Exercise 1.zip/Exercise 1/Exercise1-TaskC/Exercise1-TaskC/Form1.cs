﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise1_TaskC
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        LinkListGen<Book> mylist = new LinkListGen<Book>();//Creates an empty list

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void addBook_Click(object sender, EventArgs e)
        {
            Book book = new Book();//Book object
            string title, author, ISBN;//Properties of new book object

            title = titletext.Text;
            author = authortext.Text;
            ISBN = ISBNtext.Text;

            book = new Book(title, author, ISBN);

            mylist.AppendItem(book);//Add new book to list - calls appendItem method

            displaylist.Items.Add("Book has been added to list");
            titletext.Clear();
            authortext.Clear();
            ISBNtext.Clear();
        }

        private void display_Click(object sender, EventArgs e)
        {
            displaylist.Items.Clear();//Clears the display list
            LinkGen<Book> temp = mylist.List;

            while (temp != null)//Iterates through each item and adds to display list
            {
                displaylist.Items.Add(temp.Data.Title + " ," + temp.Data.Author + " ," + temp.Data.ISBN);
                temp = temp.Next;
            }
        }

        private void removeBook_Click(object sender, EventArgs e)
        {
            LinkGen<Book> temp = mylist.List;//Create LinkGen object called temp
            string delete = removetext.Text;//Assign new variable 

            LinkListGen<Book> tempList = new LinkListGen<Book>();//Create new LinkListGen object called tempList

            while (temp != null)//Loops through all items in mylist
            {
                if(delete.CompareTo(temp.Data.ISBN) != 0)//See if ISBN equal to user input(delete)
                {
                    tempList.AppendItem(temp.Data);//Adds item onto tempList and removes from mylist
                }
                temp= temp.Next;
            }
            displaylist.Items.Add("Book has been deleted from list");
            mylist = tempList;
        }

        private void sort_Click(object sender, EventArgs e)
        {
            //No sorting method added
        }
    }
}
