﻿namespace Exercise1_TaskC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.titletext = new System.Windows.Forms.TextBox();
            this.authortext = new System.Windows.Forms.TextBox();
            this.ISBNtext = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.removetext = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.displaylist = new System.Windows.Forms.ListBox();
            this.addBook = new System.Windows.Forms.Button();
            this.removeBook = new System.Windows.Forms.Button();
            this.display = new System.Windows.Forms.Button();
            this.sort = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Author";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "ISBN";
            // 
            // titletext
            // 
            this.titletext.Location = new System.Drawing.Point(65, 55);
            this.titletext.Name = "titletext";
            this.titletext.Size = new System.Drawing.Size(100, 20);
            this.titletext.TabIndex = 3;
            // 
            // authortext
            // 
            this.authortext.Location = new System.Drawing.Point(68, 98);
            this.authortext.Name = "authortext";
            this.authortext.Size = new System.Drawing.Size(100, 20);
            this.authortext.TabIndex = 4;
            // 
            // ISBNtext
            // 
            this.ISBNtext.Location = new System.Drawing.Point(68, 137);
            this.ISBNtext.Name = "ISBNtext";
            this.ISBNtext.Size = new System.Drawing.Size(100, 20);
            this.ISBNtext.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Add Book";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(269, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Remove Book";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(252, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "ISBN";
            // 
            // removetext
            // 
            this.removetext.Location = new System.Drawing.Point(299, 51);
            this.removetext.Name = "removetext";
            this.removetext.Size = new System.Drawing.Size(100, 20);
            this.removetext.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(502, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = "Display";
            // 
            // displaylist
            // 
            this.displaylist.FormattingEnabled = true;
            this.displaylist.Location = new System.Drawing.Point(447, 51);
            this.displaylist.Name = "displaylist";
            this.displaylist.Size = new System.Drawing.Size(329, 199);
            this.displaylist.TabIndex = 11;
            // 
            // addBook
            // 
            this.addBook.Location = new System.Drawing.Point(68, 321);
            this.addBook.Name = "addBook";
            this.addBook.Size = new System.Drawing.Size(75, 23);
            this.addBook.TabIndex = 12;
            this.addBook.Text = "Add Book";
            this.addBook.UseVisualStyleBackColor = true;
            this.addBook.Click += new System.EventHandler(this.addBook_Click);
            // 
            // removeBook
            // 
            this.removeBook.Location = new System.Drawing.Point(255, 321);
            this.removeBook.Name = "removeBook";
            this.removeBook.Size = new System.Drawing.Size(108, 23);
            this.removeBook.TabIndex = 13;
            this.removeBook.Text = "Remove Book";
            this.removeBook.UseVisualStyleBackColor = true;
            this.removeBook.Click += new System.EventHandler(this.removeBook_Click);
            // 
            // display
            // 
            this.display.Location = new System.Drawing.Point(447, 321);
            this.display.Name = "display";
            this.display.Size = new System.Drawing.Size(75, 23);
            this.display.TabIndex = 14;
            this.display.Text = "Display";
            this.display.UseVisualStyleBackColor = true;
            this.display.Click += new System.EventHandler(this.display_Click);
            // 
            // sort
            // 
            this.sort.Location = new System.Drawing.Point(593, 321);
            this.sort.Name = "sort";
            this.sort.Size = new System.Drawing.Size(75, 23);
            this.sort.TabIndex = 15;
            this.sort.Text = "Sort List";
            this.sort.UseVisualStyleBackColor = true;
            this.sort.Click += new System.EventHandler(this.sort_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.sort);
            this.Controls.Add(this.display);
            this.Controls.Add(this.removeBook);
            this.Controls.Add(this.addBook);
            this.Controls.Add(this.displaylist);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.removetext);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ISBNtext);
            this.Controls.Add(this.authortext);
            this.Controls.Add(this.titletext);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox titletext;
        private System.Windows.Forms.TextBox authortext;
        private System.Windows.Forms.TextBox ISBNtext;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox removetext;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox displaylist;
        private System.Windows.Forms.Button addBook;
        private System.Windows.Forms.Button removeBook;
        private System.Windows.Forms.Button display;
        private System.Windows.Forms.Button sort;
    }
}

